<?php 
require_once("connect.php");
if (isset($_POST["Login"])){
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	$sql = "SELECT * FROM users WHERE username= '$username'and password ='$password'";
	$runQuery = mysqli_query ($connect,$sql);
	if (mysqli_num_rows($runQuery) == 1)
	{
			session_start();
			$_SESSION["users"] = "true";
			header("location:dashboard.php");
	}else{
		echo "Wrong username or password";
	}
}
?>