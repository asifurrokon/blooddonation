<?php
require_once("connect.php");

if (isset($_POST["submit"])){
	$name = $_POST["name"];
	$address = $_POST["address"];
	$phone = $_POST["phone"];
	$d_name = $_POST["d_name"];
	$spesalist = $_POST["spesalist"];
	
	$sql = "INSERT INTO patients (name,address,phone,d_name,spesalist) VALUES ('$name','$address','$phone','$d_name','$spesalist')";
	$runQuery = mysqli_query($connect,$sql);
	if ($runQuery == true){
		header ("location:insert.php?save");
	}else{
		echo "Not insert";
	}
}
?>