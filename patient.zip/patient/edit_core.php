<?php
require_once("connect.php");
if (isset($_POST["submit"])){
	$name = $_POST["name"];
	$address = $_POST["address"];
	$phone = $_POST["phone"];
	$d_name = $_POST["d_name"];
	$spesalist = $_POST["spesalist"];
	$editingId = $_POST["editingId"];
	
	$sql = "UPDATE patients SET name='$name',address='$address',phone='$phone',d_name='$d_name',spesalist='$spesalist'WHERE id = $editingId";
	$runQuery = mysqli_query($connect,$sql);
	if ($runQuery == true){
		header("location:display.php");
	}else{
		echo "Not update";
	}
}
?>