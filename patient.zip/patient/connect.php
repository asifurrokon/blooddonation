<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "patient";
$connect = mysqli_connect($hostname,$username,$password,$dbname);
if ($connect == false){
	echo "Error !!!";
}
?>