<!DOCTYPE html>
<html>
<head>
<title> index </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>
<body>
<h3 style="width:500px;margin:auto;"> Welcome to Outdoor Patient </h3>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Outdoor_Patient</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	<ul class="navbar-nav mr-auto">
    
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Become a patient
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="registration.php">Become a patient</a>
		 
        </div>
      </li>
    </ul>
    
    <form style="width: 500px; margin:auto;"method="POST"action="">
<input type="text" name="search" id ="search"class="form-control"placeholder="Doctor name .....">
</form>
  </div>
</nav>
<hr/>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Patient Name </th>
      <th scope="col">Address </th>
      <th scope="col">Phone </th>
      <th scope="col">Doctor Name </th>
      <th scope="col">Spesalist </th>
      <th scope="col">Action </th>
    </tr>
  </thead>
  <?php
  require_once("connect.php");
  if (isset($_POST["search"])){
	$set =$_POST["search"];
		if($set){
	  $sql ="SELECT * FROM patients  WHERE d_name = '$set'";
	  $runQuery = mysqli_query($connect,$sql);
	  while($row = mysqli_fetch_array($runQuery )){
		  ?>
	<tbody>
    <tr>
      <td> <?php echo $row["name"];?> </td>
      <td> <?php echo $row["address"];?> </td>
      <td> <?php echo $row["phone"];?> </td>
      <td> <?php echo $row["d_name"];?> </td>
      <td> <?php echo $row["spesalist"];?> </td>
      <td> <a href="searchdelete_core.php?id=<?php echo $row["id"];?>"class="btn btn-danger"> Delete </a> </td>
    </tr>
  </tbody>
		  <?php
	  }
  }
  }
  ?>
</table>
</body>
</html>