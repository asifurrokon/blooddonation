<?php 
require_once("connect.php");
if (isset($_POST["Registration"])){
	$name = $_POST["name"];
	$username = $_POST["username"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	$con_password = $_POST["con_password"];
	

	$sql = "INSERT INTO users (name,username,email,password,con_password) VALUES ('$name','$username','$email','$password','$con_password') ";
	$runQuery = mysqli_query($connect,$sql);
	if ( $runQuery == true ){
		header("location:login.php");
	}else{
		header("location:registration.php");
	}
	
}
?>