<?php 
require_once("connect.php");
$getId = $_REQUEST["id"];
$sql = "DELETE FROM patients WHERE id = $getId ";
$runQuery = mysqli_query($connect,$sql);
if ($runQuery == true){
	header("location:search.php?deleted");
}else{
	echo " Not Delete";
}
?>