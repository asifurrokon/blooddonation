<?php 
require_once("connect.php");
if (isset($_POST["login"])){
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	$sql = "SELECT * FROM auth WHERE username ='$username' and password ='$password'";
	$runQuery = mysqli_query($connect,$sql);
	if (mysqli_num_rows($runQuery)== true){
		session_start();
		$_SESSION["auth"]= 'true';
		header("location:dashboard.php ");
	}else{
		echo " username or password incorrect";
	}
}


 ?>