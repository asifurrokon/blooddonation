<!DOCTYPE html>
<html>
<head>
<title>insert</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="head">
<a href="dashboard.php" class="btn btn-dark">Back</a>
<a href="display.php" class="btn btn-info">View All </a>
</div>

<div class="body"> 
<center><h3> Fill Up This Form </h3></center>

<form action="display.php" method="POST"enctype="multipart/form-data"style="width: 500px; margin:auto;">
<label for ="name"> Name </label>
<input type="text" name="name" id ="name"class="form-control">
<br/>
<label for ="phone"> Phone </label>
<input type="number" name="phone" id ="phone" placeholder="+880"class="form-control">
<br/>
<label for ="bloodgroup"> Bloodgroup </label>
<select id="bloodgroup"name="bloodgroup"class="form-control"> 
<option name="select">select </option>
<option name="a+">a+ </option>
<option name="b+ ">b+ </option>
<option name="o+">o+ </option>
<option name="ab+">ab+ </option>
<option name="a-">a- </option>
<option name="b-">b- </option>
<option name="o-">o- </option>
<option name="ab-">ab- </option>
</select>
<br/>
<label for ="division"> Division</label>
<select id="division"name="division"class="form-control"> 
<option name="select">select </option>
<option name="chittagong">chittagong</option>
<option name="dhaka">dhaka</option>
<option name="khulna">khulna</option>
<option name="rajshahi">rajshahi</option>
<option name="barisal">barisal</option>
<option name="sylhet">sylhet</option>
<option name="rangpur">rangpur</option>
<option name="mymensingh">mymensingh</option>
</select>
<br/>
<label for="district">District</label>
<select name="district"id="district"class="form-control"> 
<option name="">select chittagong</option>
<option name="">  </option>
<option name="Cox's Bazar">Cox's Bazar</option>
<option name="Rangamati">Rangamati </option>
<option name="Bandarban">Bandarban </option>
<option name="Khagrachhari">Khagrachhari</option>
<option name="Feni">Feni</option>
<option name="Lakshmipur">Lakshmipur</option>
<option name="Comilla">Comilla </option>
<option name="Noakhali">Noakhali</option>
<option name="Brahmanbaria">Brahmanbaria </option>
<option name="Chandpur">Chandpur </option>
<option name=""></option>
<option name="">select dhaka </option>
<option name=""> </option>
<option name="bandarban">Gazipur</option>
<option name="barguna">Narsingdi </option>
<option name="barisal">Manikganj </option>
<option name="bhola">Munshiganj</option>
<option name="bogra">Narayanganj</option>
<option name="brahmanbaria">Mymensingh</option>
<option name="chandpur">Sherpur </option>
<option name="chittagong">Jamalpur</option>
<option name="chuadanga">Netrokona </option>
<option name="comilla">Kishoreganj </option>	
<option name="comilla">Tangail </option>	
<option name="comilla">Faridpur </option>	
<option name="comilla">Maradipur </option>	
<option name="comilla">Shariatpur </option>	
<option name="comilla">Rajbari  </option>	
<option name="comilla">Gopalganj </option>	
<option name=""></option>	
<option name="">select khulna </option>
<option name=""></option>
<option name="Satkhira">Satkhira </option>
<option name="Jessore">Jessore  </option>
<option name="Chuadanga">Chuadanga  </option>
<option name="Narail">Narail </option>
<option name="Bagerhat">Bagerhat </option>
<option name="Magura">Magura </option>
<option name="Jhenaidah">Jhenaidah  </option>
<option name="Kushtia">Kushtia </option>
<option name="Meherpur">Meherpur  </option>
<option name=""></option>

<option name="">select rajshahi</option>
<option name=""> </option>
<option name="Satkhira">Bogra</option>
<option name="Jessore">Joypurhat</option>
<option name="Chuadanga">Naogaon</option>
<option name="Narail">Natore</option>
<option name="Bagerhat">Chapainawabganj</option>
<option name="Magura">Pabna  </option>
<option name="Jhenaidah">Rajshahi</option>
<option name="Kushtia">Sirajganj</option>
<option name=""></option>

<option name="">select barisal</option>
<option name=""></option>
<option name="Satkhira">Barguna</option>
<option name="Jessore">Barisal</option>
<option name="Chuadanga">Bhola</option>
<option name="Narail">Jhalokati</option>
<option name="Bagerhat">Patuakhali</option>
<option name="Magura">Pirojpur</option>
<option name=""></option>

<option name="">select sylhet</option>
<option name=""></option>
<option name="Satkhira">Habiganj</option>
<option name="Jessore">Moulvibazar</option>
<option name="Chuadanga">Sunamganj</option>
<option name="Narail">Sylhet</option>
<option name=""></option>
<option name="">select rangpur</option>
<option name=""></option>
<option name="Satkhira">Dinajpur</option>
<option name="Jessore">Gaibandha</option>
<option name="Chuadanga">Kurigram</option>
<option name="Narail">Lalmonirhat</option>
<option name="Narail">Nilphamari</option>
<option name="Narail">Panchagarh</option>
<option name="Narail">Rangpur</option>
<option name="Narail">Thakurgaon</option>
<option name=""></option>
<option name="">select mymensingh</option>
<option name=""></option>
<option name="Satkhira">Jamalpur</option>
<option name="Jessore">Mymensingh</option>
<option name="Chuadanga">Netrokona</option>
<option name="Narail">Sherpur</option>
</select>
<br/>
<label for ="image"> Image </label>
<input type="file" name="image"id="image"class="form-control">
<br/>
<input type="submit"value="save"name="save"class="btn btn-success">
<form>
</div>
<div class="footer">
<p> Rokon @copy 2020 </p>
</div>
</body>
</html>

