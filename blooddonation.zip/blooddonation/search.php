<!DOCTYPE html>
<html>
<head>
<title>search</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="head">
 <a href="registration.php"class="btn btn-success"> Become a Donar </a>
</div>
<div class="body">
<center><h3> Bloodgroup search.... </h3></center>
<form style="width: 500px; margin:auto;"method="POST"action="">
<input type="text" name="search" id ="search"class="form-control"placeholder="Search Your Bloodgroup .....">
<button class="form-control"> search </button>
</form>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"><center>Name</center></th>
      <th scope="col"><center>Phone</center></th>
      <th scope="col"><center>Bloodgroup</center></th>
      <th scope="col"><center>Division</center></th>
    </tr>
  </thead>
<?php
require_once("connect.php");  
$set =$_POST["search"];
if($set){
	$sql ="SELECT * FROM image  WHERE bloodgroup = '$set'";
$runQuery = mysqli_query($connect,$sql);
while($row = mysqli_fetch_array($runQuery )){
	?>
	<tbody>
    <tr>
      <td><center><?php echo $row["name"];?></center></td>
      <td><center><?php echo $row["phone"];?></center></td>
      <td><center><?php echo $row["bloodgroup"];?></center></td>
      <td><center><?php echo $row["division"];?></center></td>
    </tr>
  </tbody>
	<?php
}
}

?>
</table>
<center><h3>Division  Search..... </h3></center>
<form style="width: 500px; margin:auto;"method="POST"action="">
<input type="text" name="search" id ="search"class="form-control"placeholder="Search Your division .....">
<button class="form-control"> search </button>
</form>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"><center>Division</center></th>
      <th scope="col"><center>District</center></th>
      <th scope="col"><center>Image</center></th>
    </tr>
  </thead>
<?php
require_once("connect.php");
$set =$_POST["search"];
if($set){
	$sql ="SELECT * FROM image  WHERE division = '$set'";
$runQuery = mysqli_query($connect,$sql);
while($row = mysqli_fetch_array($runQuery )){
	?>
	<tbody>
    <tr>
      <td><center><?php echo $row["division"];?></center></td>
      <td><center><?php echo $row["district"];?></center></td>
      <td><center> <img width="80px; height = "80px;" src="images/<?php echo $row ["image"];?>"alt="image not found"></center></td>
      
    </tr>
  </tbody>
	<?php
}
}
?>
</table>
</div>

</body>