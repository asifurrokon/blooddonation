<?php 
require_once("connect.php");
if (isset($_POST["registration"])){
	$name = $_POST["name"];
	$email = $_POST["email"];
	$username = $_POST["username"];
	$password = $_POST["password"];
	$con_password = $_POST["con_password"];
	
	$sql = "INSERT INTO auth (name,email,username,password,con_password) VALUES ('$name','$email','$username','$password','$con_password')";
	$runQuery = mysqli_query($connect,$sql);
	if ($runQuery == true){
	header("location:login.php");
	}else{
		echo "not insert ";
	}
}
?>