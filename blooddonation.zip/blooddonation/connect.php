<?php
	$host_name = "localhost";
	$user_name = "root";
	$password = "";
	$db_name = "laravel";
	
$connect = mysqli_connect("localhost","root","","laravel");
if ( $connect == false ){
	echo "Error Estrabling Has Data Base Connection";
}
?>