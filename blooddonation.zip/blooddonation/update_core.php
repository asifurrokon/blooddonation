<?php
require_once("connect.php");
if (isset($_POST["update"])){
	$name = $_POST["name"];
	$phone = $_POST["phone"];
	$bloodgroup = $_POST["bloodgroup"];
	$division = $_POST["division"];
	$district = $_POST["district"];

	$sql = "UPDATE image SET name='$name',phone='$phone',bloodgroup='$bloodgroup',division='$division',district='$district'";
	$runQuery = mysqli_query($connect,$sql);
	if ($runQuery == true){
		header("location:display.php");
	}else{
		echo "not updated";
	}
}



?>